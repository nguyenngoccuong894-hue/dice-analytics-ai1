package com.diceanalytics.ai.domain.model

/**
 * Trạng thái vòng đời của dịch vụ phân tích thời gian thực.
 */
enum class AnalysisEngineState {
    IDLE,
    RUNNING,
    PAUSED,
    STOPPED
}

/**
 * Hồ sơ tối ưu hóa CPU, bộ nhớ và pin cho bộ lấy mẫu khung hình.
 */
enum class PowerOptimizationProfile(
    val labelVi: String,
    val targetFps: Int,
    val downsampleFactor: Int,
    val frameDiffThreshold: Float
) {
    BATTERY_SAVER(
        labelVi = "Tiết kiệm pin (2 FPS)",
        targetFps = 2,
        downsampleFactor = 4,
        frameDiffThreshold = 0.035f
    ),
    BALANCED(
        labelVi = "Cân bằng (5 FPS)",
        targetFps = 5,
        downsampleFactor = 2,
        frameDiffThreshold = 0.020f
    ),
    RESPONSIVE(
        labelVi = "Mượt (10 FPS)",
        targetFps = 10,
        downsampleFactor = 2,
        frameDiffThreshold = 0.012f
    )
}

/**
 * Kết quả nhận diện cho một viên xúc xắc đơn lẻ từ bộ thị giác máy tính cục bộ.
 */
data class DetectedDie(
    val index: Int,
    val value: Int,
    val confidencePercent: Float,
    val left: Int,
    val top: Int,
    val width: Int,
    val height: Int
)

/**
 * Kết quả phân tích một khung hình mô phỏng xúc xắc hoàn chỉnh.
 */
data class DiceFrameAnalysis(
    val dice: List<DetectedDie>,
    val total: Int,
    val averageConfidencePercent: Float,
    val processingTimeMs: Long,
    val timestampMs: Long = System.currentTimeMillis(),
    val skippedAsStaticFrame: Boolean = false
)

/**
 * Tổng hợp thống kê mô tả (chỉ phục vụ mục đích học tập & mô tả dữ liệu).
 */
data class DescriptiveStatistics(
    val totalRolls: Int = 0,
    val meanSum: Double = 0.0,
    val standardDeviation: Double = 0.0,
    val averageConfidence: Double = 0.0,
    val minSum: Int = 0,
    val maxSum: Int = 0,
    val evenCount: Int = 0,
    val oddCount: Int = 0,
    val lowGroupCount: Int = 0,  // Tổng 3..10
    val highGroupCount: Int = 0, // Tổng 11..18
    val sumHistogram: Map<Int, Int> = (3..18).associateWith { 0 },
    val faceFrequency: Map<Int, Int> = (1..6).associateWith { 0 },
    val recentTotals: List<Int> = emptyList()
)

/**
 * Trạng thái cấp quyền minh bạch của ứng dụng.
 */
data class PermissionOverview(
    val overlayGranted: Boolean = false,
    val notificationsGranted: Boolean = false,
    val mediaProjectionAuthorized: Boolean = false,
    val privacyConsentAccepted: Boolean = false
) {
    val readyForOverlayCapture: Boolean
        get() = overlayGranted && mediaProjectionAuthorized && privacyConsentAccepted
}
