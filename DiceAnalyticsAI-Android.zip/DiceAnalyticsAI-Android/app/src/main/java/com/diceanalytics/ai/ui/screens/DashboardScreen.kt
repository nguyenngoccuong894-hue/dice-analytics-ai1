package com.diceanalytics.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceanalytics.ai.data.local.DiceRollEntity
import com.diceanalytics.ai.domain.model.DescriptiveStatistics
import com.diceanalytics.ai.ui.components.FaceFrequencyChart
import com.diceanalytics.ai.ui.components.SumDistributionChart
import java.util.Locale

@Composable
fun DashboardScreen(
    statistics: DescriptiveStatistics,
    recentRolls: List<DiceRollEntity>,
    onResetData: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Thống kê mô tả cục bộ",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "Dữ liệu lưu trữ trong Room Database · Không đưa ra dự đoán cá cược",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF64748B)
                    )
                }
                OutlinedButton(onClick = onResetData) {
                    Text("Đặt lại")
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCell(
                    label = "Tổng số lượt",
                    value = statistics.totalRolls.toString(),
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Trung bình",
                    value = String.format(Locale.US, "%.2f", statistics.meanSum),
                    modifier = Modifier.weight(1f)
                )
                MetricCell(
                    label = "Độ tin cậy TB",
                    value = String.format(Locale.US, "%.1f%%", statistics.averageConfidence),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                SumDistributionChart(
                    histogram = statistics.sumHistogram,
                    totalRolls = statistics.totalRolls,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                FaceFrequencyChart(
                    faceFrequency = statistics.faceFrequency,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        item {
            Text(
                text = "Lịch sử nhận diện gần đây (${recentRolls.size})",
                style = MaterialTheme.typography.titleMedium
            )
        }

        if (recentRolls.isEmpty()) {
            item {
                Text(
                    text = "Chưa có dữ liệu. Hãy bắt đầu dịch vụ phân tích trên màn hình mô phỏng xúc xắc.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            items(recentRolls.take(25), key = { it.id }) { roll ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "[${roll.dieOne}, ${roll.dieTwo}, ${roll.dieThree}]  Tổng: ${roll.totalSum}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp
                        )
                        Text(
                            text = String.format(
                                Locale.US,
                                "%.1f%% · %dms",
                                roll.confidencePercent,
                                roll.processingTimeMs
                            ),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = Color(0xFF475569)
                        )
                    }
                    HorizontalDivider(color = Color(0xFFE2E8F0))
                }
            }
        }
    }
}

@Composable
private fun MetricCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = label, fontSize = 11.sp, color = Color(0xFF64748B))
            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF0F172A)
            )
        }
    }
}
