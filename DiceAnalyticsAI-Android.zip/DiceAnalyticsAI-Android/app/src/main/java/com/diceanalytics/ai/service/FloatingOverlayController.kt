package com.diceanalytics.ai.service

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.diceanalytics.ai.ui.components.FloatingOverlayContent
import com.diceanalytics.ai.ui.theme.DiceAnalyticsTheme
import kotlin.math.roundToInt

/**
 * Điều khiển lớp phủ nổi (Floating Overlay) sử dụng WindowManager + Jetpack Compose.
 * Hỗ trợ kéo di chuyển (movable), thay đổi kích thước (resizable) và thu gọn (collapsible).
 */
class FloatingOverlayController(
    private val context: Context,
    private val onStartOrResume: () -> Unit,
    private val onPause: () -> Unit,
    private val onStop: () -> Unit,
    private val onReset: () -> Unit
) : LifecycleOwner, SavedStateRegistryOwner {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private var composeView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var isCollapsed by mutableStateOf(false)
    private var expandedWidthPx: Int = dpToPx(276)
    private var expandedHeightPx: Int = dpToPx(236)

    private val minWidthPx = dpToPx(236)
    private val maxWidthPx = dpToPx(360)
    private val minHeightPx = dpToPx(196)
    private val maxHeightPx = dpToPx(340)
    private val collapsedSizePx = dpToPx(56)

    fun show() {
        if (composeView != null) return
        if (!Settings.canDrawOverlays(context)) return

        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            expandedWidthPx,
            expandedHeightPx,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(16)
            y = dpToPx(96)
        }
        layoutParams = params

        val view = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@FloatingOverlayController)
            setViewTreeSavedStateRegistryOwner(this@FloatingOverlayController)
            setContent {
                DiceAnalyticsTheme {
                    FloatingOverlayContent(
                        isCollapsed = isCollapsed,
                        onToggleCollapse = { toggleCollapse() },
                        onDragDelta = { dx, dy -> moveBy(dx, dy) },
                        onResizeDelta = { dw, dh -> resizeBy(dw, dh) },
                        onStartOrResume = onStartOrResume,
                        onPause = onPause,
                        onStop = onStop,
                        onReset = onReset
                    )
                }
            }
        }

        windowManager.addView(view, params)
        composeView = view
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    private fun toggleCollapse() {
        val params = layoutParams ?: return
        val view = composeView ?: return
        isCollapsed = !isCollapsed
        if (isCollapsed) {
            params.width = collapsedSizePx
            params.height = collapsedSizePx
        } else {
            params.width = expandedWidthPx
            params.height = expandedHeightPx
        }
        windowManager.updateViewLayout(view, params)
    }

    private fun moveBy(dx: Float, dy: Float) {
        val params = layoutParams ?: return
        val view = composeView ?: return
        val metrics = context.resources.displayMetrics
        params.x = (params.x + dx.roundToInt()).coerceIn(0, metrics.widthPixels - params.width)
        params.y = (params.y + dy.roundToInt()).coerceIn(0, metrics.heightPixels - params.height)
        windowManager.updateViewLayout(view, params)
    }

    private fun resizeBy(dw: Float, dh: Float) {
        if (isCollapsed) return
        val params = layoutParams ?: return
        val view = composeView ?: return
        expandedWidthPx = (expandedWidthPx + dw.roundToInt()).coerceIn(minWidthPx, maxWidthPx)
        expandedHeightPx = (expandedHeightPx + dh.roundToInt()).coerceIn(minHeightPx, maxHeightPx)
        params.width = expandedWidthPx
        params.height = expandedHeightPx
        windowManager.updateViewLayout(view, params)
    }

    fun hide() {
        val view = composeView ?: return
        try {
            lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
            windowManager.removeView(view)
        } catch (_: Exception) {
            // Đã gỡ trước đó
        } finally {
            composeView = null
            layoutParams = null
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * context.resources.displayMetrics.density).roundToInt()
    }
}
