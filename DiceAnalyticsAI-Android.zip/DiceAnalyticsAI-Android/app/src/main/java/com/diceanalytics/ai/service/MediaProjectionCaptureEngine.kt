package com.diceanalytics.ai.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import com.diceanalytics.ai.domain.model.PowerOptimizationProfile
import kotlin.math.max

/**
 * Quản lý phiên chụp màn hình được người dùng ủy quyền qua MediaProjection API.
 *
 * Bảo mật & quyền riêng tư:
 * - Tuân thủ tuyệt đối cơ chế bảo mật hệ điều hành Android (FLAG_SECURE tự động hiển thị đen
 *   trên nội dung được bảo vệ; không vượt qua bất kỳ rào cản bảo mật nào).
 * - Chỉ xử lý khung hình tạm trong RAM, giải phóng Image ngay lập tức và không lưu ảnh chụp.
 * - Tối ưu CPU/RAM/Pin bằng giảm độ phân giải VirtualDisplay và giới hạn tốc độ lấy mẫu FPS.
 */
class MediaProjectionCaptureEngine(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val profileProvider: () -> PowerOptimizationProfile,
    private val onFrameCaptured: (Bitmap) -> Unit,
    private val onProjectionStopped: () -> Unit
) {
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var reusableBitmap: Bitmap? = null

    @Volatile
    private var isPaused: Boolean = false

    @Volatile
    private var lastAnalyzedElapsedMs: Long = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stop()
            onProjectionStopped()
        }
    }

    fun start() {
        val metrics = context.resources.displayMetrics
        val profile = profileProvider()
        val scale = max(2, profile.downsampleFactor)
        val targetWidth = max(320, metrics.widthPixels / scale)
        val targetHeight = max(480, metrics.heightPixels / scale)

        captureThread = HandlerThread("DiceCaptureThread").apply { start() }
        captureHandler = Handler(captureThread!!.looper)

        // Bắt buộc đăng ký callback trước khi tạo VirtualDisplay trên Android 14+
        mediaProjection.registerCallback(projectionCallback, captureHandler)

        imageReader = ImageReader.newInstance(
            targetWidth,
            targetHeight,
            PixelFormat.RGBA_8888,
            2
        ).apply {
            setOnImageAvailableListener({ reader ->
                handleImageAvailable(reader)
            }, captureHandler)
        }

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "DiceSimulatorAuthorizedDisplay",
            targetWidth,
            targetHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
    }

    private fun handleImageAvailable(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        try {
            if (isPaused) return

            val profile = profileProvider()
            val minIntervalMs = 1000L / max(1, profile.targetFps)
            val now = SystemClock.elapsedRealtime()
            if (now - lastAnalyzedElapsedMs < minIntervalMs) {
                return
            }
            lastAnalyzedElapsedMs = now

            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmapWidth = image.width + rowPadding / pixelStride

            val bitmap = reusableBitmap?.takeIf {
                it.width == bitmapWidth && it.height == image.height && !it.isRecycled
            } ?: Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888).also {
                reusableBitmap?.recycle()
                reusableBitmap = it
            }

            bitmap.copyPixelsFromBuffer(buffer)
            val cropped = if (bitmapWidth != image.width) {
                Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
            } else {
                bitmap
            }

            onFrameCaptured(cropped)

            if (cropped !== bitmap) {
                cropped.recycle()
            }
        } finally {
            // Luôn đóng Image ngay lập tức để ngăn tràn bộ nhớ đệm Surface
            image.close()
        }
    }

    fun stop() {
        try {
            imageReader?.setOnImageAvailableListener(null, null)
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection.unregisterCallback(projectionCallback)
            mediaProjection.stop()
        } catch (_: Exception) {
            // Bỏ qua nếu phiên MediaProjection đã bị hệ thống thu hồi trước đó
        } finally {
            virtualDisplay = null
            imageReader = null
            reusableBitmap?.recycle()
            reusableBitmap = null
            captureThread?.quitSafely()
            captureThread = null
            captureHandler = null
        }
    }
}
