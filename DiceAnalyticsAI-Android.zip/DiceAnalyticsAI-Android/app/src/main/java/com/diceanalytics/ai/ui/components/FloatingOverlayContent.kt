package com.diceanalytics.ai.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceanalytics.ai.domain.model.AnalysisEngineState
import com.diceanalytics.ai.service.AnalysisSessionBus
import java.util.Locale

/**
 * Giao diện Jetpack Compose cho lớp phủ nổi (Floating Overlay):
 * - Kéo thanh tiêu đề hoặc biểu tượng thu gọn để di chuyển tự do.
 * - Kéo góc dưới bên phải để thay đổi kích thước (resizable).
 * - Chuyển đổi nhanh giữa chế độ đầy đủ và thu gọn (collapsible).
 * - Tích hợp nút Bắt đầu/Tiếp tục, Tạm dừng, Dừng và Đặt lại.
 */
@Composable
fun FloatingOverlayContent(
    isCollapsed: Boolean,
    onToggleCollapse: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onResizeDelta: (Float, Float) -> Unit,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onReset: () -> Unit
) {
    val engineState by AnalysisSessionBus.engineState.collectAsState()
    val latestAnalysis by AnalysisSessionBus.latestAnalysis.collectAsState()
    val powerProfile by AnalysisSessionBus.powerProfile.collectAsState()

    if (isCollapsed) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                },
            shape = CircleShape,
            color = Color(0xFF0F172A),
            border = BorderStroke(1.5.dp, Color(0xFF3B82F6)),
            shadowElevation = 6.dp
        ) {
            IconButton(onClick = onToggleCollapse, modifier = Modifier.fillMaxSize()) {
                val label = latestAnalysis?.total?.toString() ?: "DA"
                Text(
                    text = label,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
        return
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xF50F172A),
        border = BorderStroke(1.dp, Color(0xFF334155)),
        shadowElevation = 8.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // Thanh tiêu đề cho phép kéo di chuyển lớp phủ
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                onDragDelta(dragAmount.x, dragAmount.y)
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DragIndicator,
                            contentDescription = "Di chuyển lớp phủ",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Dice Analytics",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleCollapse, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = "Thu gọn",
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(onClick = onStop, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dừng dịch vụ",
                                tint = Color(0xFFF87171),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 6.dp),
                    color = Color(0xFF1E293B)
                )

                // Trạng thái & Hồ sơ tối ưu
                val stateLabel = when (engineState) {
                    AnalysisEngineState.RUNNING -> "Đang phân tích"
                    AnalysisEngineState.PAUSED -> "Đang tạm dừng"
                    AnalysisEngineState.STOPPED -> "Đã dừng"
                    AnalysisEngineState.IDLE -> "Sẵn sàng"
                }
                Text(
                    text = "$stateLabel · ${powerProfile.targetFps} FPS cục bộ",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Giá trị xúc xắc, tổng điểm & phần trăm độ tin cậy
                val dice = latestAnalysis?.dice.orEmpty()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (i in 0 until 3) {
                            val die = dice.getOrNull(i)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = die?.value?.toString() ?: "–",
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = die?.let {
                                        String.format(Locale.US, "%.0f%%", it.confidencePercent)
                                    } ?: "--%",
                                    color = Color(0xFF38BDF8),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Tổng",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                        Text(
                            text = latestAnalysis?.total?.toString() ?: "–",
                            color = Color(0xFF34D399),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        )
                        val avgConf = latestAnalysis?.averageConfidencePercent ?: 0f
                        Text(
                            text = String.format(Locale.US, "Tin cậy %.1f%%", avgConf),
                            color = Color(0xFFCBD5E1),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Thanh điều khiển: Bắt đầu/Tiếp tục, Tạm dừng, Đặt lại
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isRunning = engineState == AnalysisEngineState.RUNNING
                    OverlayActionButton(
                        icon = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        label = if (isRunning) "Tạm dừng" else "Tiếp tục",
                        tint = if (isRunning) Color(0xFFFBBF24) else Color(0xFF34D399),
                        onClick = if (isRunning) onPause else onStartOrResume,
                        modifier = Modifier.weight(1f)
                    )
                    OverlayActionButton(
                        icon = Icons.Default.Refresh,
                        label = "Đặt lại",
                        tint = Color(0xFF93C5FD),
                        onClick = onReset,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Tay cầm thay đổi kích thước (Resize Handle) ở góc dưới phải
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(26.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onResizeDelta(dragAmount.x, dragAmount.y)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.OpenInFull,
                    contentDescription = "Thay đổi kích thước lớp phủ",
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(13.dp)
                )
            }
        }
    }
}

@Composable
private fun OverlayActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(34.dp),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF1E293B),
        border = BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = label,
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
    }
}
