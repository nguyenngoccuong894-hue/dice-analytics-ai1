package com.diceanalytics.ai.data.repository

import com.diceanalytics.ai.data.local.DiceRollDao
import com.diceanalytics.ai.data.local.DiceRollEntity
import com.diceanalytics.ai.domain.model.DescriptiveStatistics
import com.diceanalytics.ai.domain.model.DiceFrameAnalysis
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Kho dữ liệu cục bộ quản lý bản ghi nhận diện và tính toán thống kê mô tả.
 * Không chứa logic dự đoán cá cược hay tín hiệu đặt cược.
 */
class DiceAnalyticsRepository(
    private val diceRollDao: DiceRollDao
) {
    val recentRolls: Flow<List<DiceRollEntity>> = diceRollDao.observeRecentRolls(limit = 150)

    val descriptiveStatistics: Flow<DescriptiveStatistics> =
        diceRollDao.observeAllRollsAscending().map { rolls ->
            computeDescriptiveStatistics(rolls)
        }

    suspend fun recordAnalysis(analysis: DiceFrameAnalysis) {
        if (analysis.dice.size != 3) return
        val entity = DiceRollEntity(
            dieOne = analysis.dice[0].value,
            dieTwo = analysis.dice[1].value,
            dieThree = analysis.dice[2].value,
            totalSum = analysis.total,
            confidencePercent = analysis.averageConfidencePercent,
            processingTimeMs = analysis.processingTimeMs,
            recordedAtMs = analysis.timestampMs
        )
        diceRollDao.insertRoll(entity)
    }

    suspend fun resetAllData() {
        diceRollDao.clearAllRolls()
    }

    private fun computeDescriptiveStatistics(rolls: List<DiceRollEntity>): DescriptiveStatistics {
        if (rolls.isEmpty()) return DescriptiveStatistics()

        val sumHistogram = (3..18).associateWith { 0 }.toMutableMap()
        val faceFrequency = (1..6).associateWith { 0 }.toMutableMap()

        var sumAccum = 0.0
        var confidenceAccum = 0.0
        var minSum = Int.MAX_VALUE
        var maxSum = Int.MIN_VALUE
        var evenCount = 0
        var oddCount = 0
        var lowGroupCount = 0
        var highGroupCount = 0

        for (roll in rolls) {
            val total = roll.totalSum
            sumAccum += total
            confidenceAccum += roll.confidencePercent
            if (total < minSum) minSum = total
            if (total > maxSum) maxSum = total

            if (total % 2 == 0) evenCount++ else oddCount++
            if (total <= 10) lowGroupCount++ else highGroupCount++

            sumHistogram[total] = (sumHistogram[total] ?: 0) + 1
            faceFrequency[roll.dieOne] = (faceFrequency[roll.dieOne] ?: 0) + 1
            faceFrequency[roll.dieTwo] = (faceFrequency[roll.dieTwo] ?: 0) + 1
            faceFrequency[roll.dieThree] = (faceFrequency[roll.dieThree] ?: 0) + 1
        }

        val mean = sumAccum / rolls.size
        val variance = rolls.sumOf { (it.totalSum - mean).pow(2) } / rolls.size
        val stdDev = sqrt(variance)

        return DescriptiveStatistics(
            totalRolls = rolls.size,
            meanSum = mean,
            standardDeviation = stdDev,
            averageConfidence = confidenceAccum / rolls.size,
            minSum = minSum,
            maxSum = maxSum,
            evenCount = evenCount,
            oddCount = oddCount,
            lowGroupCount = lowGroupCount,
            highGroupCount = highGroupCount,
            sumHistogram = sumHistogram,
            faceFrequency = faceFrequency,
            recentTotals = rolls.takeLast(30).map { it.totalSum }
        )
    }
}
