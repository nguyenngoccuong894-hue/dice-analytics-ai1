package com.diceanalytics.ai.service

import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.diceanalytics.ai.DiceAnalyticsApp
import com.diceanalytics.ai.MainActivity
import com.diceanalytics.ai.R
import com.diceanalytics.ai.domain.model.AnalysisEngineState
import com.diceanalytics.ai.vision.DiceVisionAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android Foreground Service quản lý vòng đời MediaProjection, lớp phủ nổi và phân tích
 * thị giác máy tính cục bộ theo thời gian thực.
 */
class DiceAnalysisForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val visionAnalyzer = DiceVisionAnalyzer()

    private var captureEngine: MediaProjectionCaptureEngine? = null
    private var overlayController: FloatingOverlayController? = null

    private var lastSavedSignature: String? = null
    private var lastSavedTimeMs: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
                }
                startForegroundWithProjection(resultCode, data)
            }
            ACTION_PAUSE -> pauseAnalysis()
            ACTION_RESUME -> resumeAnalysis()
            ACTION_RESET -> resetSession()
            ACTION_STOP -> stopAnalysisAndSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithProjection(resultCode: Int, projectionData: Intent?) {
        val notification = buildNotification(isPaused = false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = if (resultCode == Activity.RESULT_OK && projectionData != null) {
            projectionManager.getMediaProjection(resultCode, projectionData)
        } else {
            null
        }

        if (projection == null) {
            stopAnalysisAndSelf()
            return
        }

        AnalysisSessionBus.updateState(AnalysisEngineState.RUNNING)
        visionAnalyzer.resetMotionCache()

        overlayController?.hide()
        overlayController = FloatingOverlayController(
            context = this,
            onStartOrResume = { resumeAnalysis() },
            onPause = { pauseAnalysis() },
            onStop = { stopAnalysisAndSelf() },
            onReset = { resetSession() }
        ).also { it.show() }

        captureEngine?.stop()
        captureEngine = MediaProjectionCaptureEngine(
            context = this,
            mediaProjection = projection,
            profileProvider = { AnalysisSessionBus.powerProfile.value },
            onFrameCaptured = { bitmap ->
                val profile = AnalysisSessionBus.powerProfile.value
                val result = visionAnalyzer.analyzeFrame(
                    bitmap = bitmap,
                    frameDiffThreshold = profile.frameDiffThreshold
                ) ?: return@MediaProjectionCaptureEngine

                AnalysisSessionBus.publishAnalysis(result)

                if (!result.skippedAsStaticFrame && result.dice.size == 3) {
                    val signature = result.dice.joinToString("-") { it.value.toString() }
                    val now = System.currentTimeMillis()
                    // Chống ghi trùng cùng một lượt tung tĩnh trong vòng 900ms
                    if (signature != lastSavedSignature || now - lastSavedTimeMs > 900L) {
                        lastSavedSignature = signature
                        lastSavedTimeMs = now
                        val app = application as DiceAnalyticsApp
                        serviceScope.launch(Dispatchers.IO) {
                            app.repository.recordAnalysis(result)
                        }
                    }
                }
            },
            onProjectionStopped = {
                stopAnalysisAndSelf()
            }
        ).also { it.start() }
    }

    private fun pauseAnalysis() {
        captureEngine?.setPaused(true)
        AnalysisSessionBus.updateState(AnalysisEngineState.PAUSED)
        updateNotification(isPaused = true)
    }

    private fun resumeAnalysis() {
        captureEngine?.setPaused(false)
        visionAnalyzer.resetMotionCache()
        AnalysisSessionBus.updateState(AnalysisEngineState.RUNNING)
        updateNotification(isPaused = false)
    }

    private fun resetSession() {
        lastSavedSignature = null
        lastSavedTimeMs = 0L
        visionAnalyzer.resetMotionCache()
        AnalysisSessionBus.resetRuntimeCounters()
        val app = application as DiceAnalyticsApp
        serviceScope.launch(Dispatchers.IO) {
            app.repository.resetAllData()
        }
    }

    private fun stopAnalysisAndSelf() {
        captureEngine?.stop()
        captureEngine = null
        overlayController?.hide()
        overlayController = null
        AnalysisSessionBus.updateState(AnalysisEngineState.STOPPED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateNotification(isPaused: Boolean) {
        val manager = getSystemService(android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(isPaused))
    }

    private fun buildNotification(isPaused: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleAction = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        val toggleLabel = if (isPaused) getString(R.string.action_resume) else getString(R.string.action_pause)
        val togglePending = PendingIntent.getService(
            this,
            1,
            Intent(this, DiceAnalysisForegroundService::class.java).apply { action = toggleAction },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopPending = PendingIntent.getService(
            this,
            2,
            Intent(this, DiceAnalysisForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (isPaused) {
            getString(R.string.notification_title_paused)
        } else {
            getString(R.string.notification_title_running)
        }

        return NotificationCompat.Builder(this, DiceAnalyticsApp.CHANNEL_ID_ANALYSIS)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(title)
            .setContentText(getString(R.string.notification_text_local))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .addAction(0, toggleLabel, togglePending)
            .addAction(0, getString(R.string.action_stop), stopPending)
            .build()
    }

    override fun onDestroy() {
        captureEngine?.stop()
        overlayController?.hide()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 2026
        const val ACTION_START = "com.diceanalytics.ai.action.START"
        const val ACTION_PAUSE = "com.diceanalytics.ai.action.PAUSE"
        const val ACTION_RESUME = "com.diceanalytics.ai.action.RESUME"
        const val ACTION_RESET = "com.diceanalytics.ai.action.RESET"
        const val ACTION_STOP = "com.diceanalytics.ai.action.STOP"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_PROJECTION_DATA = "extra_projection_data"
    }
}
