package com.diceanalytics.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceanalytics.ai.domain.model.AnalysisEngineState
import com.diceanalytics.ai.domain.model.PermissionOverview
import com.diceanalytics.ai.domain.model.PowerOptimizationProfile

@Composable
fun PermissionPrivacyScreen(
    permissions: PermissionOverview,
    engineState: AnalysisEngineState,
    powerProfile: PowerOptimizationProfile,
    processedFrames: Long,
    skippedStaticFrames: Long,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onPrivacyConsentChange: (Boolean) -> Unit,
    onStartCaptureService: () -> Unit,
    onPauseService: () -> Unit,
    onResumeService: () -> Unit,
    onStopService: () -> Unit,
    onResetService: () -> Unit,
    onSelectPowerProfile: (PowerOptimizationProfile) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Quản lý quyền & Dịch vụ nền",
            style = MaterialTheme.typography.titleLarge
        )

        // Cam kết quyền riêng tư & tuân thủ bảo mật Android
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Minh bạch quyền riêng tư & Giới hạn bảo mật",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "• Chỉ hoạt động sau khi người dùng chủ động cấp phép MediaProjection và Overlay.\n" +
                        "• Xử lý thị giác máy tính 100% cục bộ trong RAM; ứng dụng không khai báo quyền INTERNET.\n" +
                        "• Không vượt qua FLAG_SECURE hay nội dung được bảo vệ của hệ điều hành Android.\n" +
                        "• Chỉ phục vụ thống kê mô tả giáo dục, không cung cấp dự đoán hay tín hiệu cá cược.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF475569)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = permissions.privacyConsentAccepted,
                        onCheckedChange = onPrivacyConsentChange
                    )
                    Text(
                        text = "Tôi xác nhận chỉ sử dụng trong môi trường mô phỏng xúc xắc giáo dục được ủy quyền.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Các quyền hệ thống Android
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(text = "Cấp quyền hệ thống Android", style = MaterialTheme.typography.titleMedium)

                PermissionRow(
                    title = "Hiển thị lớp phủ nổi (SYSTEM_ALERT_WINDOW)",
                    status = if (permissions.overlayGranted) "Đã cấp phép" else "Chưa cấp phép",
                    granted = permissions.overlayGranted,
                    actionLabel = "Mở cài đặt",
                    onAction = onRequestOverlayPermission
                )

                PermissionRow(
                    title = "Thông báo Foreground Service (POST_NOTIFICATIONS)",
                    status = if (permissions.notificationsGranted) "Đã cấp phép" else "Chưa cấp phép",
                    granted = permissions.notificationsGranted,
                    actionLabel = "Cấp quyền",
                    onAction = onRequestNotificationPermission
                )
            }
        }

        // Điều khiển Foreground Service (Start, Pause, Stop, Reset)
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Điều khiển dịch vụ phân tích (${engineState.name})",
                    style = MaterialTheme.typography.titleMedium
                )
                val canStart = permissions.overlayGranted && permissions.privacyConsentAccepted
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (engineState == AnalysisEngineState.IDLE || engineState == AnalysisEngineState.STOPPED) {
                        Button(
                            onClick = onStartCaptureService,
                            enabled = canStart,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Bắt đầu")
                        }
                    } else if (engineState == AnalysisEngineState.RUNNING) {
                        Button(onClick = onPauseService, modifier = Modifier.weight(1f)) {
                            Text("Tạm dừng")
                        }
                    } else {
                        Button(onClick = onResumeService, modifier = Modifier.weight(1f)) {
                            Text("Tiếp tục")
                        }
                    }

                    OutlinedButton(
                        onClick = onStopService,
                        enabled = engineState == AnalysisEngineState.RUNNING || engineState == AnalysisEngineState.PAUSED,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Dừng")
                    }

                    OutlinedButton(onClick = onResetService, modifier = Modifier.weight(1f)) {
                        Text("Đặt lại")
                    }
                }
            }
        }

        // Tối ưu hóa CPU, bộ nhớ & pin
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Tối ưu hóa CPU, bộ nhớ & pin",
                    style = MaterialTheme.typography.titleMedium
                )
                PowerOptimizationProfile.entries.forEach { profile ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = powerProfile == profile,
                            onClick = { onSelectPowerProfile(profile) }
                        )
                        Text(
                            text = "${profile.labelVi} · Giảm tỉ lệ 1/${profile.downsampleFactor}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                Text(
                    text = "Khung hình đã phân tích: $processedFrames · Khung tĩnh đã bỏ qua: $skippedStaticFrames",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
            }
        }
    }
}

@Composable
private fun PermissionRow(
    title: String,
    status: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(
                text = status,
                fontSize = 12.sp,
                color = if (granted) Color(0xFF059669) else Color(0xFFDC2626)
            )
        }
        if (!granted) {
            OutlinedButton(onClick = onAction) {
                Text(actionLabel)
            }
        }
    }
}
