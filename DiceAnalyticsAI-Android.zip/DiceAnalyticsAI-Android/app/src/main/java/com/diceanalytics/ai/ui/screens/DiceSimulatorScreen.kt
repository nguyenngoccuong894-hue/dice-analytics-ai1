package com.diceanalytics.ai.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Môi trường mô phỏng xúc xắc giáo dục được ủy quyền ngay trong ứng dụng.
 * Tạo khung hình xúc xắc độ tương phản chuẩn để kiểm thử MediaProjection và bộ phân tích CV.
 */
@Composable
fun DiceSimulatorScreen() {
    var diceValues by remember { mutableStateOf(listOf(3, 5, 2)) }
    var autoRoll by remember { mutableStateOf(false) }

    LaunchedEffect(autoRoll) {
        while (autoRoll) {
            delay(1800L)
            diceValues = List(3) { Random.nextInt(1, 7) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Môi trường mô phỏng xúc xắc giáo dục",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = "Khởi chạy dịch vụ nền từ tab Quyền & Dịch vụ, sau đó tung xúc xắc tại đây để hệ thống nhận diện tự động theo thời gian thực.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF475569)
        )

        // Bàn mô phỏng tối màu với 3 viên xúc xắc trắng độ tương phản cao
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(Color(0xFF0F172A), RoundedCornerShape(16.dp))
        ) {
            val dieSize = minOf(size.width / 4.2f, size.height * 0.52f)
            val gap = dieSize * 0.32f
            val totalWidth = dieSize * 3f + gap * 2f
            val startX = (size.width - totalWidth) / 2f
            val startY = (size.height - dieSize) / 2f

            diceValues.forEachIndexed { index, value ->
                val x = startX + index * (dieSize + gap)
                drawRoundRect(
                    color = Color(0xFFF8FAFC),
                    topLeft = Offset(x, startY),
                    size = Size(dieSize, dieSize),
                    cornerRadius = CornerRadius(dieSize * 0.16f, dieSize * 0.16f)
                )

                val pipRadius = dieSize * 0.088f
                val pipPositions = getPipOffsets(value)
                pipPositions.forEach { (nx, ny) ->
                    val pipColor = if (value == 1 || value == 4) Color(0xFFDC2626) else Color(0xFF0F172A)
                    drawCircle(
                        color = pipColor,
                        radius = pipRadius,
                        center = Offset(x + nx * dieSize, startY + ny * dieSize)
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { diceValues = List(3) { Random.nextInt(1, 7) } },
                modifier = Modifier.weight(1f)
            ) {
                Text("Tung xúc xắc")
            }
            OutlinedButton(
                onClick = { autoRoll = !autoRoll },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (autoRoll) "Dừng tự tung" else "Tự tung (1,8 giây)")
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Giá trị mô phỏng hiện tại: ${diceValues.joinToString(" · ")} — Tổng: ${diceValues.sum()}",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF334155)
        )
    }
}

private fun getPipOffsets(value: Int): List<Pair<Float, Float>> = when (value) {
    1 -> listOf(0.5f to 0.5f)
    2 -> listOf(0.28f to 0.28f, 0.72f to 0.72f)
    3 -> listOf(0.28f to 0.28f, 0.5f to 0.5f, 0.72f to 0.72f)
    4 -> listOf(0.28f to 0.28f, 0.72f to 0.28f, 0.28f to 0.72f, 0.72f to 0.72f)
    5 -> listOf(0.28f to 0.28f, 0.72f to 0.28f, 0.5f to 0.5f, 0.28f to 0.72f, 0.72f to 0.72f)
    else -> listOf(
        0.28f to 0.25f, 0.72f to 0.25f,
        0.28f to 0.50f, 0.72f to 0.50f,
        0.28f to 0.75f, 0.72f to 0.75f
    )
}
