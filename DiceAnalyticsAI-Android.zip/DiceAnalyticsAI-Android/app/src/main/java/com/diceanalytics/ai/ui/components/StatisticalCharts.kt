package com.diceanalytics.ai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

/**
 * Biểu đồ cột tần suất tổng điểm 3 xúc xắc (3–18) kèm đường cong phân bố lý thuyết giáo dục.
 */
@Composable
fun SumDistributionChart(
    histogram: Map<Int, Int>,
    totalRolls: Int,
    modifier: Modifier = Modifier
) {
    val theoreticalWays = mapOf(
        3 to 1, 4 to 3, 5 to 6, 6 to 10, 7 to 15, 8 to 21, 9 to 25, 10 to 27,
        11 to 27, 12 to 25, 13 to 21, 14 to 15, 15 to 10, 16 to 6, 17 to 3, 18 to 1
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Phân bố tổng điểm (3–18) so với kỳ vọng lý thuyết",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(10.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .padding(horizontal = 4.dp)
        ) {
            val keys = (3..18).toList()
            val slotWidth = size.width / keys.size
            val barWidth = slotWidth * 0.64f
            val maxObserved = max(1, histogram.values.maxOrNull() ?: 1)
            val maxExpected = if (totalRolls > 0) (totalRolls * 27f / 216f) else 1f
            val yMax = max(maxObserved.toFloat(), maxExpected) * 1.15f

            // Đường lưới ngang
            for (step in 0..3) {
                val y = size.height * (step / 3f)
                drawLine(
                    color = Color(0xFFE2E8F0),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
            }

            // Cột thực nghiệm
            keys.forEachIndexed { index, sum ->
                val count = histogram[sum] ?: 0
                val barHeight = (count / yMax) * (size.height - 8.dp.toPx())
                val left = index * slotWidth + (slotWidth - barWidth) / 2f
                drawRoundRect(
                    color = Color(0xFF1D4ED8),
                    topLeft = Offset(left, size.height - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
            }

            // Đường phân bố xác suất lý thuyết 3d6
            if (totalRolls > 0) {
                val path = Path()
                keys.forEachIndexed { index, sum ->
                    val expected = totalRolls * ((theoreticalWays[sum] ?: 0) / 216f)
                    val cx = index * slotWidth + slotWidth / 2f
                    val cy = size.height - (expected / yMax) * (size.height - 8.dp.toPx())
                    if (index == 0) path.moveTo(cx, cy) else path.lineTo(cx, cy)
                }
                drawPath(
                    path = path,
                    color = Color(0xFFD97706),
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(3, 6, 9, 10, 11, 14, 18).forEach { label ->
                Text(
                    text = label.toString(),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

/**
 * Biểu đồ tần suất từng mặt xúc xắc (1–6).
 */
@Composable
fun FaceFrequencyChart(
    faceFrequency: Map<Int, Int>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Tần suất từng mặt xúc xắc (1–6)",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(10.dp))

        val maxCount = max(1, faceFrequency.values.maxOrNull() ?: 1)
        val totalFaces = max(1, faceFrequency.values.sum())

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..6).forEach { face ->
                val count = faceFrequency[face] ?: 0
                val pct = (count * 100f) / totalFaces
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Mặt $face",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFF334155)
                    )
                    Canvas(
                        modifier = Modifier
                            .weight(1f)
                            .height(16.dp)
                    ) {
                        drawRoundRect(
                            color = Color(0xFFE2E8F0),
                            size = size,
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                        val fillWidth = (count.toFloat() / maxCount.toFloat()) * size.width
                        drawRoundRect(
                            color = Color(0xFF0F766E),
                            size = Size(fillWidth, size.height),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }
                    Text(
                        text = "$count (${"%.1f".format(pct)}%)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFF475569)
                    )
                }
            }
        }
    }
}
