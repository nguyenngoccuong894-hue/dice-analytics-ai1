package com.diceanalytics.ai.service

import com.diceanalytics.ai.domain.model.AnalysisEngineState
import com.diceanalytics.ai.domain.model.DiceFrameAnalysis
import com.diceanalytics.ai.domain.model.PowerOptimizationProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Kênh trạng thái phản ứng (StateFlow) đồng bộ trực tiếp giữa Foreground Service,
 * lớp phủ nổi (Floating Overlay) và ViewModel theo kiến trúc MVVM.
 */
object AnalysisSessionBus {
    private val _engineState = MutableStateFlow(AnalysisEngineState.IDLE)
    val engineState: StateFlow<AnalysisEngineState> = _engineState.asStateFlow()

    private val _latestAnalysis = MutableStateFlow<DiceFrameAnalysis?>(null)
    val latestAnalysis: StateFlow<DiceFrameAnalysis?> = _latestAnalysis.asStateFlow()

    private val _powerProfile = MutableStateFlow(PowerOptimizationProfile.BALANCED)
    val powerProfile: StateFlow<PowerOptimizationProfile> = _powerProfile.asStateFlow()

    private val _skippedStaticFrames = MutableStateFlow(0L)
    val skippedStaticFrames: StateFlow<Long> = _skippedStaticFrames.asStateFlow()

    private val _processedFrames = MutableStateFlow(0L)
    val processedFrames: StateFlow<Long> = _processedFrames.asStateFlow()

    fun updateState(state: AnalysisEngineState) {
        _engineState.value = state
    }

    fun publishAnalysis(analysis: DiceFrameAnalysis) {
        if (analysis.skippedAsStaticFrame) {
            _skippedStaticFrames.value += 1
        } else {
            _processedFrames.value += 1
            _latestAnalysis.value = analysis
        }
    }

    fun updatePowerProfile(profile: PowerOptimizationProfile) {
        _powerProfile.value = profile
    }

    fun resetRuntimeCounters() {
        _latestAnalysis.value = null
        _skippedStaticFrames.value = 0L
        _processedFrames.value = 0L
    }
}
