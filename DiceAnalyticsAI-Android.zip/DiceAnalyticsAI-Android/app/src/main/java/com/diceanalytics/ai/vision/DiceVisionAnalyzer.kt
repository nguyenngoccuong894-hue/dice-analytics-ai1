package com.diceanalytics.ai.vision

import android.graphics.Bitmap
import android.os.SystemClock
import com.diceanalytics.ai.domain.model.DetectedDie
import com.diceanalytics.ai.domain.model.DiceFrameAnalysis
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Bộ phân tích thị giác máy tính cục bộ nhận diện chấm xúc xắc (1–6) trên khung hình
 * từ môi trường mô phỏng xúc xắc giáo dục được ủy quyền.
 *
 * Tối ưu hóa hiệu năng:
 * - Tái sử dụng mảng bộ đệm pixel để hạn chế cấp phát GC.
 * - Kiểm tra sai khác khung hình (frame-diff gating) để bỏ qua khung hình tĩnh.
 * - Tách vùng mặt xúc xắc sáng trên nền tối và đếm thành phần liên thông (connected components)
 *   cho từng chấm (pip) nhằm tính giá trị và phần trăm độ tin cậy.
 */
class DiceVisionAnalyzer {

    private var previousSampleLuma: IntArray = IntArray(0)
    private var reusablePixels: IntArray = IntArray(0)

    fun resetMotionCache() {
        previousSampleLuma = IntArray(0)
    }

    /**
     * Phân tích một Bitmap đã được thu gọn kích thước (downsampled) từ ImageReader.
     */
    fun analyzeFrame(
        bitmap: Bitmap,
        frameDiffThreshold: Float = 0.02f,
        forceAnalyze: Boolean = false
    ): DiceFrameAnalysis? {
        val startNs = SystemClock.elapsedRealtimeNanos()
        val width = bitmap.width
        val height = bitmap.height
        val totalPixels = width * height
        if (totalPixels <= 0) return null

        if (reusablePixels.size < totalPixels) {
            reusablePixels = IntArray(totalPixels)
        }
        bitmap.getPixels(reusablePixels, 0, width, 0, 0, width, height)

        // 1. Kiểm tra thay đổi khung hình trên lưới thưa để tiết kiệm CPU & pin
        val changedRatio = computeSparseFrameDiff(reusablePixels, width, height)
        if (!forceAnalyze && changedRatio < frameDiffThreshold) {
            return DiceFrameAnalysis(
                dice = emptyList(),
                total = 0,
                averageConfidencePercent = 0f,
                processingTimeMs = (SystemClock.elapsedRealtimeNanos() - startNs) / 1_000_000L,
                skippedAsStaticFrame = true
            )
        }

        // 2. Chuyển đổi sang ảnh xám (luminance) và tìm các vùng sáng (mặt xúc xắc)
        val luma = IntArray(totalPixels)
        var minLuma = 255
        var maxLuma = 0
        for (i in 0 until totalPixels) {
            val px = reusablePixels[i]
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            val y = (r * 77 + g * 150 + b * 29) shr 8
            luma[i] = y
            if (y < minLuma) minLuma = y
            if (y > maxLuma) maxLuma = y
        }

        // Ngưỡng tách mặt xúc xắc sáng trên nền bàn mô phỏng tối
        val dieThreshold = minLuma + ((maxLuma - minLuma) * 0.58f).toInt()
        val dieBoxes = findBrightSquareRegions(luma, width, height, dieThreshold)
            .sortedBy { it.left }
            .take(3)

        if (dieBoxes.isEmpty()) {
            return null
        }

        // 3. Phân tích chấm (pips) bên trong từng ROI xúc xắc
        val detectedDice = mutableListOf<DetectedDie>()
        dieBoxes.forEachIndexed { idx, box ->
            val dieResult = recognizeDieInRegion(luma, width, box, idx)
            if (dieResult != null) {
                detectedDice.add(dieResult)
            }
        }

        if (detectedDice.isEmpty()) return null

        val elapsedMs = max(1L, (SystemClock.elapsedRealtimeNanos() - startNs) / 1_000_000L)
        val total = detectedDice.sumOf { it.value }
        val avgConf = detectedDice.map { it.confidencePercent }.average().toFloat()

        return DiceFrameAnalysis(
            dice = detectedDice,
            total = total,
            averageConfidencePercent = avgConf,
            processingTimeMs = elapsedMs,
            skippedAsStaticFrame = false
        )
    }

    private fun computeSparseFrameDiff(pixels: IntArray, width: Int, height: Int): Float {
        val step = 8
        val cols = (width + step - 1) / step
        val rows = (height + step - 1) / step
        val sampleCount = cols * rows
        if (sampleCount == 0) return 1f

        val currentSample = IntArray(sampleCount)
        var idx = 0
        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val px = pixels[y * width + x]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                currentSample[idx++] = (r * 77 + g * 150 + b * 29) shr 8
                x += step
            }
            y += step
        }

        if (previousSampleLuma.size != sampleCount) {
            previousSampleLuma = currentSample
            return 1f
        }

        var changed = 0
        for (i in 0 until sampleCount) {
            if (abs(currentSample[i] - previousSampleLuma[i]) > 14) {
                changed++
            }
        }
        previousSampleLuma = currentSample
        return changed.toFloat() / sampleCount.toFloat()
    }

    private data class BoundingBox(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        val area: Int
    ) {
        val width: Int get() = right - left + 1
        val height: Int get() = bottom - top + 1
    }

    private fun findBrightSquareRegions(
        luma: IntArray,
        width: Int,
        height: Int,
        threshold: Int
    ): List<BoundingBox> {
        val visited = BooleanArray(width * height)
        val queue = IntArray(width * height)
        val results = mutableListOf<BoundingBox>()
        val minDieArea = max(120, (width * height) / 220)
        val maxDieArea = (width * height) / 4

        for (y in 0 until height step 2) {
            for (x in 0 until width step 2) {
                val startIdx = y * width + x
                if (visited[startIdx] || luma[startIdx] < threshold) continue

                var head = 0
                var tail = 0
                queue[tail++] = startIdx
                visited[startIdx] = true

                var minX = x
                var maxX = x
                var minY = y
                var maxY = y
                var area = 0

                while (head < tail) {
                    val curr = queue[head++]
                    val cx = curr % width
                    val cy = curr / width
                    area++
                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy

                    val neighbors = intArrayOf(
                        if (cx > 0) curr - 1 else -1,
                        if (cx + 1 < width) curr + 1 else -1,
                        if (cy > 0) curr - width else -1,
                        if (cy + 1 < height) curr + width else -1
                    )
                    for (n in neighbors) {
                        if (n >= 0 && !visited[n] && luma[n] >= threshold) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                }

                if (area in minDieArea..maxDieArea) {
                    val bw = maxX - minX + 1
                    val bh = maxY - minY + 1
                    val aspect = bw.toFloat() / max(1, bh).toFloat()
                    val fillRatio = area.toFloat() / (bw * bh).toFloat()
                    if (aspect in 0.72f..1.38f && fillRatio > 0.62f) {
                        results.add(BoundingBox(minX, minY, maxX, maxY, area))
                    }
                }
            }
        }
        return results
    }

    private fun recognizeDieInRegion(
        luma: IntArray,
        stride: Int,
        box: BoundingBox,
        index: Int
    ): DetectedDie? {
        // Thu hẹp lề trong 12% để tránh nhiễu viền bo góc xúc xắc
        val marginX = max(2, (box.width * 0.12f).toInt())
        val marginY = max(2, (box.height * 0.12f).toInt())
        val roiL = box.left + marginX
        val roiT = box.top + marginY
        val roiR = box.right - marginX
        val roiB = box.bottom - marginY
        val roiW = roiR - roiL + 1
        val roiH = roiB - roiT + 1
        if (roiW <= 4 || roiH <= 4) return null

        // Tính ngưỡng sáng cục bộ bên trong mặt xúc xắc
        var sumLuma = 0L
        var count = 0
        for (y in roiT..roiB) {
            for (x in roiL..roiR) {
                sumLuma += luma[y * stride + x]
                count++
            }
        }
        val meanFaceLuma = (sumLuma / max(1, count)).toInt()
        val pipThreshold = max(30, (meanFaceLuma * 0.68f).toInt())

        val visited = BooleanArray(roiW * roiH)
        val queue = IntArray(roiW * roiH)
        val minPipArea = max(4, (roiW * roiH) / 140)
        val maxPipArea = max(12, (roiW * roiH) / 7)

        var pipCount = 0
        var circularityAccum = 0f

        for (ry in 0 until roiH) {
            for (rx in 0 until roiW) {
                val localIdx = ry * roiW + rx
                if (visited[localIdx]) continue
                val globalVal = luma[(roiT + ry) * stride + (roiL + rx)]
                if (globalVal > pipThreshold) continue

                var head = 0
                var tail = 0
                queue[tail++] = localIdx
                visited[localIdx] = true

                var pMinX = rx
                var pMaxX = rx
                var pMinY = ry
                var pMaxY = ry
                var pArea = 0

                while (head < tail) {
                    val curr = queue[head++]
                    val cx = curr % roiW
                    val cy = curr / roiW
                    pArea++
                    if (cx < pMinX) pMinX = cx
                    if (cx > pMaxX) pMaxX = cx
                    if (cy < pMinY) pMinY = cy
                    if (cy > pMaxY) pMaxY = cy

                    val neighbors = intArrayOf(
                        if (cx > 0) curr - 1 else -1,
                        if (cx + 1 < roiW) curr + 1 else -1,
                        if (cy > 0) curr - roiW else -1,
                        if (cy + 1 < roiH) curr + roiW else -1
                    )
                    for (n in neighbors) {
                        if (n >= 0 && !visited[n]) {
                            val nx = n % roiW
                            val ny = n / roiW
                            if (luma[(roiT + ny) * stride + (roiL + nx)] <= pipThreshold) {
                                visited[n] = true
                                queue[tail++] = n
                            }
                        }
                    }
                }

                if (pArea in minPipArea..maxPipArea) {
                    val pw = pMaxX - pMinX + 1
                    val ph = pMaxY - pMinY + 1
                    val ratio = pw.toFloat() / max(1, ph).toFloat()
                    if (ratio in 0.55f..1.80f) {
                        pipCount++
                        val idealCircleFill = 0.785f
                        val actualFill = pArea.toFloat() / (pw * ph).toFloat()
                        val shapeScore = 1f - min(0.35f, abs(actualFill - idealCircleFill))
                        circularityAccum += shapeScore
                    }
                }
            }
        }

        if (pipCount !in 1..6) return null

        val avgShapeScore = circularityAccum / pipCount.toFloat()
        val squarenessScore = 1f - min(0.25f, abs(1f - box.width.toFloat() / max(1, box.height).toFloat()))
        val rawConfidence = (avgShapeScore * 0.65f + squarenessScore * 0.35f) * 100f
        val clampedConfidence = rawConfidence.coerceIn(72.0f, 99.4f)

        return DetectedDie(
            index = index,
            value = pipCount,
            confidencePercent = clampedConfidence,
            left = box.left,
            top = box.top,
            width = box.width,
            height = box.height
        )
    }
}
