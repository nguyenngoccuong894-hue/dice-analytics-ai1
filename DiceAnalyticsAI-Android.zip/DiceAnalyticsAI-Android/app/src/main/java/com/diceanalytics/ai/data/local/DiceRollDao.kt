package com.diceanalytics.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DiceRollDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoll(roll: DiceRollEntity): Long

    @Query("SELECT * FROM dice_rolls ORDER BY recorded_at_ms DESC LIMIT :limit")
    fun observeRecentRolls(limit: Int = 200): Flow<List<DiceRollEntity>>

    @Query("SELECT * FROM dice_rolls ORDER BY recorded_at_ms ASC")
    fun observeAllRollsAscending(): Flow<List<DiceRollEntity>>

    @Query("SELECT COUNT(*) FROM dice_rolls")
    fun observeRollCount(): Flow<Int>

    @Query("DELETE FROM dice_rolls")
    suspend fun clearAllRolls()
}
