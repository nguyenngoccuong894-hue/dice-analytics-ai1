package com.diceanalytics.ai.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.diceanalytics.ai.DiceAnalyticsApp
import com.diceanalytics.ai.data.local.DiceRollEntity
import com.diceanalytics.ai.domain.model.AnalysisEngineState
import com.diceanalytics.ai.domain.model.DescriptiveStatistics
import com.diceanalytics.ai.domain.model.DiceFrameAnalysis
import com.diceanalytics.ai.domain.model.PermissionOverview
import com.diceanalytics.ai.domain.model.PowerOptimizationProfile
import com.diceanalytics.ai.service.AnalysisSessionBus
import com.diceanalytics.ai.service.DiceAnalysisForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel trung tâm theo kiến trúc MVVM, kết nối Room Database cục bộ,
 * trạng thái quyền minh bạch và Foreground Service.
 */
class DiceAnalyticsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as DiceAnalyticsApp
    private val repository = app.repository

    val engineState: StateFlow<AnalysisEngineState> = AnalysisSessionBus.engineState
    val latestAnalysis: StateFlow<DiceFrameAnalysis?> = AnalysisSessionBus.latestAnalysis
    val powerProfile: StateFlow<PowerOptimizationProfile> = AnalysisSessionBus.powerProfile
    val processedFrames: StateFlow<Long> = AnalysisSessionBus.processedFrames
    val skippedStaticFrames: StateFlow<Long> = AnalysisSessionBus.skippedStaticFrames

    val statistics: StateFlow<DescriptiveStatistics> = repository.descriptiveStatistics
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = DescriptiveStatistics()
        )

    val recentRolls: StateFlow<List<DiceRollEntity>> = repository.recentRolls
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = emptyList()
        )

    private val _permissions = MutableStateFlow(PermissionOverview())
    val permissions: StateFlow<PermissionOverview> = _permissions.asStateFlow()

    init {
        refreshPermissions(notificationsGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU)
    }

    fun refreshPermissions(notificationsGranted: Boolean) {
        val overlayGranted = Settings.canDrawOverlays(app)
        _permissions.value = _permissions.value.copy(
            overlayGranted = overlayGranted,
            notificationsGranted = notificationsGranted
        )
    }

    fun setPrivacyConsentAccepted(accepted: Boolean) {
        _permissions.value = _permissions.value.copy(privacyConsentAccepted = accepted)
    }

    fun onMediaProjectionGranted(resultCode: Int, data: Intent) {
        _permissions.value = _permissions.value.copy(mediaProjectionAuthorized = true)
        val serviceIntent = Intent(app, DiceAnalysisForegroundService::class.java).apply {
            action = DiceAnalysisForegroundService.ACTION_START
            putExtra(DiceAnalysisForegroundService.EXTRA_RESULT_CODE, resultCode)
            putExtra(DiceAnalysisForegroundService.EXTRA_PROJECTION_DATA, data)
        }
        ContextCompat.startForegroundService(app, serviceIntent)
    }

    fun pauseAnalysis() {
        sendServiceAction(DiceAnalysisForegroundService.ACTION_PAUSE)
    }

    fun resumeAnalysis() {
        sendServiceAction(DiceAnalysisForegroundService.ACTION_RESUME)
    }

    fun stopAnalysis() {
        _permissions.value = _permissions.value.copy(mediaProjectionAuthorized = false)
        sendServiceAction(DiceAnalysisForegroundService.ACTION_STOP)
    }

    fun resetData() {
        if (engineState.value == AnalysisEngineState.RUNNING || engineState.value == AnalysisEngineState.PAUSED) {
            sendServiceAction(DiceAnalysisForegroundService.ACTION_RESET)
        } else {
            AnalysisSessionBus.resetRuntimeCounters()
            viewModelScope.launch {
                repository.resetAllData()
            }
        }
    }

    fun selectPowerProfile(profile: PowerOptimizationProfile) {
        AnalysisSessionBus.updatePowerProfile(profile)
    }

    private fun sendServiceAction(actionName: String) {
        val intent = Intent(app, DiceAnalysisForegroundService::class.java).apply {
            action = actionName
        }
        app.startService(intent)
    }
}
