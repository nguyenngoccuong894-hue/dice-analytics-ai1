package com.diceanalytics.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.diceanalytics.ai.ui.screens.DashboardScreen
import com.diceanalytics.ai.ui.screens.DiceSimulatorScreen
import com.diceanalytics.ai.ui.screens.PermissionPrivacyScreen
import com.diceanalytics.ai.ui.theme.DiceAnalyticsTheme
import com.diceanalytics.ai.ui.viewmodel.DiceAnalyticsViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: DiceAnalyticsViewModel by viewModels()

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            viewModel.onMediaProjectionGranted(result.resultCode, data)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshPermissions(notificationsGranted = granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DiceAnalyticsTheme {
                var selectedTab by rememberSaveable { mutableIntStateOf(0) }
                val permissions by viewModel.permissions.collectAsState()
                val engineState by viewModel.engineState.collectAsState()
                val powerProfile by viewModel.powerProfile.collectAsState()
                val processedFrames by viewModel.processedFrames.collectAsState()
                val skippedStaticFrames by viewModel.skippedStaticFrames.collectAsState()
                val statistics by viewModel.statistics.collectAsState()
                val recentRolls by viewModel.recentRolls.collectAsState()

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.Casino, contentDescription = null) },
                                label = { Text("Mô phỏng") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.BarChart, contentDescription = null) },
                                label = { Text("Thống kê") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Security, contentDescription = null) },
                                label = { Text("Quyền & Dịch vụ") }
                            )
                        }
                    }
                ) { innerPadding ->
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            0 -> DiceSimulatorScreen()
                            1 -> DashboardScreen(
                                statistics = statistics,
                                recentRolls = recentRolls,
                                onResetData = { viewModel.resetData() }
                            )
                            2 -> PermissionPrivacyScreen(
                                permissions = permissions,
                                engineState = engineState,
                                powerProfile = powerProfile,
                                processedFrames = processedFrames,
                                skippedStaticFrames = skippedStaticFrames,
                                onRequestOverlayPermission = { openOverlayPermissionSettings() },
                                onRequestNotificationPermission = { requestNotificationPermission() },
                                onPrivacyConsentChange = { viewModel.setPrivacyConsentAccepted(it) },
                                onStartCaptureService = { requestMediaProjectionConsent() },
                                onPauseService = { viewModel.pauseAnalysis() },
                                onResumeService = { viewModel.resumeAnalysis() },
                                onStopService = { viewModel.stopAnalysis() },
                                onResetService = { viewModel.resetData() },
                                onSelectPowerProfile = { viewModel.selectPowerProfile(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        viewModel.refreshPermissions(notificationsGranted = notifGranted)
    }

    private fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun requestMediaProjectionConsent() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }
}
