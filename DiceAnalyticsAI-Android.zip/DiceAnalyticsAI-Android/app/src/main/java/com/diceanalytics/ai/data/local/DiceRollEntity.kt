package com.diceanalytics.ai.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dice_rolls")
data class DiceRollEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "die_one")
    val dieOne: Int,

    @ColumnInfo(name = "die_two")
    val dieTwo: Int,

    @ColumnInfo(name = "die_three")
    val dieThree: Int,

    @ColumnInfo(name = "total_sum")
    val totalSum: Int,

    @ColumnInfo(name = "confidence_percent")
    val confidencePercent: Float,

    @ColumnInfo(name = "processing_ms")
    val processingTimeMs: Long,

    @ColumnInfo(name = "source_tag")
    val sourceTag: String = "authorized_simulator",

    @ColumnInfo(name = "recorded_at_ms")
    val recordedAtMs: Long = System.currentTimeMillis()
)
