package com.diceanalytics.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [DiceRollEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DiceAnalyticsDatabase : RoomDatabase() {

    abstract fun diceRollDao(): DiceRollDao

    companion object {
        @Volatile
        private var INSTANCE: DiceAnalyticsDatabase? = null

        fun getInstance(context: Context): DiceAnalyticsDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DiceAnalyticsDatabase::class.java,
                    "dice_analytics_local.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
