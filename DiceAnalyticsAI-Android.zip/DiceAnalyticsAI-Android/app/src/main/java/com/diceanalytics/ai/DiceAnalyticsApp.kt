package com.diceanalytics.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.diceanalytics.ai.data.local.DiceAnalyticsDatabase
import com.diceanalytics.ai.data.repository.DiceAnalyticsRepository

class DiceAnalyticsApp : Application() {

    lateinit var database: DiceAnalyticsDatabase
        private set

    lateinit var repository: DiceAnalyticsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = DiceAnalyticsDatabase.getInstance(this)
        repository = DiceAnalyticsRepository(database.diceRollDao())
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_ANALYSIS,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID_ANALYSIS = "dice_analysis_foreground_channel"
    }
}
